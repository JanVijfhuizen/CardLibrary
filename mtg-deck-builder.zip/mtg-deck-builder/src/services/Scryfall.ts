import { ref } from 'vue';
import { MtgCard, CardFilters } from '../types/mtg';

const cards = ref<MtgCard[]>([]);
const isLoading = ref<boolean>(false);
const error = ref<string | null>(null);

export function useScryfallAPI() {
  const searchCards = async (filters?: CardFilters) => {
    isLoading.value = true;
    error.value = null;

    try {
      let url = 'https://api.scryfall.com/cards/search?q=game%3Apaper';

      if (filters) {
        const queryParts: string[] = ['game:paper'];

        // If user typed a card name or search term
        if (filters.query && filters.query.trim() !== '') {
          // Use Scryfall's field-specific name search or general text search
          const cleanQuery = filters.query.trim();
          queryParts.push(`name:"${cleanQuery}"`);
        }

        if (filters.color) {
          const colorMap: Record<string, string> = {
            White: 'c:w',
            Blue: 'c:u',
            Black: 'c:b',
            Red: 'c:r',
            Green: 'c:g',
            Colorless: 'c:c',
            Multicolor: 'c:m'
          };
          if (colorMap[filters.color]) {
            queryParts.push(colorMap[filters.color]);
          }
        }

        if (filters.type) {
          queryParts.push(`t:${filters.type.toLowerCase()}`);
        }

        if (filters.maxCost !== null && filters.maxCost !== undefined) {
          queryParts.push(`cmc<=${filters.maxCost}`);
        }

        url = `https://api.scryfall.com/cards/search?q=${encodeURIComponent(queryParts.join(' '))}`;
      }

      const response = await fetch(url);

      if (response.status === 404) {
        // If exact name search yields nothing, try a fallback fuzzy/general text search
        if (filters?.query) {
          const fallbackUrl = `https://api.scryfall.com/cards/search?q=${encodeURIComponent('game:paper ' + filters.query.trim())}`;
          const fallbackRes = await fetch(fallbackUrl);
          if (fallbackRes.ok) {
            const fallbackData = await fallbackRes.json();
            parseCardData(fallbackData);
            return;
          }
        }
        cards.value = [];
        return;
      }

      if (!response.ok) {
        throw new Error(`Scryfall API error (${response.status})`);
      }

      const data = await response.json();
      parseCardData(data);
    } catch (err: any) {
      error.value = err.message || 'Failed to load card catalog from Scryfall.';
      console.error('Scryfall fetch failed:', err);
    } finally {
      isLoading.value = false;
    }
  };

  const parseCardData = (data: any) => {
    if (data.object === 'list' && Array.isArray(data.data)) {
      cards.value = data.data.map((card: any) => ({
        id: card.id,
        name: card.name,
        type: card.type_line || 'Unknown',
        color: parseColor(card.colors),
        cost: card.cmc !== undefined ? Number(card.cmc) : 0,
        tags: card.keywords || [],
        image:
          card.image_uris?.normal ||
          card.card_faces?.[0]?.image_uris?.normal ||
          ''
      }));
    } else {
      cards.value = [];
    }
  };

  const parseColor = (colors: string[]): string => {
    if (!colors || colors.length === 0) return 'Colorless';
    if (colors.length > 1) return 'Multicolor';
    const map: Record<string, string> = {
      W: 'White',
      U: 'Blue',
      B: 'Black',
      R: 'Red',
      G: 'Green'
    };
    return map[colors[0]] || 'Colorless';
  };

  return {
    cards,
    isLoading,
    error,
    searchCards
  };
}