<script setup lang="ts">
import { ref, watch, onMounted } from 'vue';
import { useDecks } from '../composables/useDecks';
import { useScryfallAPI } from '../services/scryfall';
import { CardFilters, MtgCard } from '../types/mtg';

const {
  activeDeck,
  totalCardCount,
  isDeckValid,
  closeDeck,
  addCard,
  removeCard,
  saveActiveDeck,
  getShareableDecklist
} = useDecks();

const { cards, searchCards, isLoading, error } = useScryfallAPI();

const filters = ref<CardFilters>({
  query: '',
  color: '',
  type: '',
  maxCost: null
});

let searchTimeout: ReturnType<typeof setTimeout> | null = null;

onMounted(async () => {
  await searchCards(filters.value);
});

// Debounced live search against Scryfall whenever filters change
watch(
  filters,
  (newFilters) => {
    if (searchTimeout) clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      searchCards(newFilters);
    }, 350);
  },
  { deep: true }
);

const handleAdd = (card: MtgCard) => {
  const result = addCard(card);
  if (!result.success && result.message) {
    alert(result.message);
  }
};

const handleSave = () => {
  saveActiveDeck();
  alert('Deck saved successfully!');
  closeDeck();
};

const handleShare = () => {
  const decklistText = getShareableDecklist();
  navigator.clipboard
    .writeText(decklistText)
    .then(() => {
      alert('Decklist copied to clipboard!');
    })
    .catch(() => {
      prompt('Copy your decklist:', decklistText);
    });
};
</script>

<template>
  <div class="screen builder-screen">
    <!-- Header Controls -->
    <header class="builder-header">
      <button @click="closeDeck" class="secondary-btn">← Back to Decks</button>
      <input
        v-if="activeDeck"
        type="text"
        v-model="activeDeck.name"
        placeholder="Deck Name"
        class="deck-name-input"
      />
      <div class="deck-stats">
        <span class="count">{{ totalCardCount }} cards</span>
        <span :class="['badge', isDeckValid ? 'valid' : 'invalid']">
          {{ isDeckValid ? 'Valid Deck (60+)' : `Needs ${60 - totalCardCount} more cards` }}
        </span>
      </div>
      <div class="builder-actions">
        <button @click="handleShare" class="secondary-btn">Share Decklist</button>
        <button @click="handleSave" class="primary-btn">Save Deck</button>
      </div>
    </header>

    <!-- Split Workspace -->
    <div class="builder-workspace">
      <!-- Left: Card Catalog Browser -->
      <div class="pane card-browser">
        <div class="filter-bar">
          <input
            type="text"
            v-model="filters.query"
            placeholder="Search any MTG card (e.g. Mikaeus, Sol Ring)..."
          />
          <select v-model="filters.color">
            <option value="">All Colors</option>
            <option value="White">White</option>
            <option value="Blue">Blue</option>
            <option value="Black">Black</option>
            <option value="Red">Red</option>
            <option value="Green">Green</option>
            <option value="Multicolor">Multicolor</option>
            <option value="Colorless">Colorless</option>
          </select>
          <select v-model="filters.type">
            <option value="">All Types</option>
            <option value="Creature">Creature</option>
            <option value="Instant">Instant</option>
            <option value="Sorcery">Sorcery</option>
            <option value="Artifact">Artifact</option>
            <option value="Enchantment">Enchantment</option>
            <option value="Planeswalker">Planeswalker</option>
            <option value="Land">Land</option>
          </select>
        </div>

        <div v-if="isLoading" class="loading-state">
          Searching Scryfall database...
        </div>

        <div v-else-if="error" class="error-state">
          {{ error }}
        </div>

        <div v-else-if="cards.length === 0" class="loading-state">
          No cards found. Check your spelling (e.g., "Mikaeus") or clear filters.
        </div>

        <div v-else class="catalog-grid">
          <div v-for="card in cards" :key="card.id" class="card-item">
            <img :src="card.image" :alt="card.name" loading="lazy" />
            <div class="card-footer">
              <span class="card-title" :title="card.name">{{ card.name }}</span>
              <button @click="handleAdd(card)" class="primary-btn add-btn">+ Add</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Right: Active Deck Grid Workspace -->
      <div class="pane deck-workspace">
        <h2>Current Deck</h2>
        <div class="deck-grid-view">
          <div
            v-if="!activeDeck || activeDeck.entries.length === 0"
            class="empty-deck"
          >
            Your deck is empty. Add cards from the left panel!
          </div>
          <div
            v-for="entry in activeDeck?.entries"
            :key="entry.card.id"
            class="deck-grid-item"
          >
            <img :src="entry.card.image" :alt="entry.card.name" />
            <div class="deck-item-controls">
              <span>{{ entry.quantity }}x</span>
              <div class="qty-buttons">
                <button @click="removeCard(entry.card.id)">-</button>
                <button @click="handleAdd(entry.card)">+</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.builder-screen {
  padding: 20px;
  max-width: 1500px;
  margin: 0 auto;
  height: 100vh;
  display: flex;
  flex-direction: column;
}
.builder-header {
  background: #1e1e1e;
  padding: 15px 20px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 15px;
  margin-bottom: 20px;
}
.deck-name-input {
  background: #121212;
  border: 1px solid #333;
  color: white;
  padding: 8px 12px;
  border-radius: 4px;
  font-size: 1.1rem;
}
.deck-stats {
  display: flex;
  align-items: center;
  gap: 12px;
}
.badge {
  padding: 4px 10px;
  border-radius: 4px;
  font-size: 0.85rem;
  font-weight: bold;
}
.badge.valid {
  background-color: #065f46;
  color: #34d399;
}
.badge.invalid {
  background-color: #7f1d1d;
  color: #fca5a5;
}
.builder-actions {
  display: flex;
  gap: 10px;
}
.builder-workspace {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  flex: 1;
  overflow: hidden;
}
.pane {
  background: #1e1e1e;
  border-radius: 8px;
  padding: 15px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.filter-bar {
  display: flex;
  gap: 10px;
  margin-bottom: 15px;
}
.filter-bar input,
.filter-bar select {
  background: #121212;
  border: 1px solid #333;
  color: white;
  padding: 8px;
  border-radius: 4px;
}
.filter-bar input {
  flex: 1;
}
.catalog-grid,
.deck-grid-view {
  flex: 1;
  overflow-y: auto;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
  gap: 12px;
  align-content: start;
  padding-right: 5px;
}
.card-item,
.deck-grid-item {
  background: #121212;
  border-radius: 6px;
  overflow: hidden;
  border: 1px solid #2a2a2a;
  display: flex;
  flex-direction: column;
}
.card-item img,
.deck-grid-item img {
  width: 100%;
  height: auto;
  display: block;
}
.card-footer {
  padding: 8px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.card-title {
  font-size: 0.8rem;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.add-btn {
  padding: 4px;
  font-size: 0.75rem;
}
.deck-item-controls {
  padding: 6px;
  background: #181818;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.9rem;
}
.qty-buttons {
  display: flex;
  gap: 4px;
}
.qty-buttons button {
  background: #333;
  color: white;
  border: none;
  width: 22px;
  height: 22px;
  border-radius: 3px;
  cursor: pointer;
}
.qty-buttons button:hover {
  background: #444;
}
.loading-state,
.empty-deck {
  color: #888;
  text-align: center;
  margin-top: 40px;
  grid-column: 1 / -1;
}
.error-state {
  color: #fca5a5;
  text-align: center;
  margin-top: 40px;
  grid-column: 1 / -1;
}
</style>