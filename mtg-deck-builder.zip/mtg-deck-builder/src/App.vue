<script setup lang="ts">
import { useDecks } from './composables/useDecks';
import DeckOverview from './components/DeckOverview.vue';
import DeckBuilder from './components/DeckBuilder.vue';

const { activeDeck } = useDecks();
</script>

<template>
  <main class="app-container">
    <DeckBuilder v-if="activeDeck" />
    <DeckOverview v-else />
  </main>
</template>

<style>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: system-ui, -apple-system, sans-serif;
}
body {
  background-color: #121212;
  color: #e0e0e0;
  min-height: 100vh;
}
.primary-btn {
  background-color: #3b82f6;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
}
.primary-btn:hover { background-color: #2563eb; }
.secondary-btn {
  background-color: #374151;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 6px;
  cursor: pointer;
}
.secondary-btn:hover { background-color: #4b5563; }
.danger-btn {
  background-color: #ef4444;
  color: white;
  border: none;
  padding: 6px 12px;
  border-radius: 6px;
  cursor: pointer;
}
.danger-btn:hover { background-color: #dc2626; }
</style>