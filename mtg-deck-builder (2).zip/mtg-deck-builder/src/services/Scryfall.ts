
import { ref } from 'vue';
import type { MtgCard, CardFilters } from '../types/mtg';

const cards = ref<MtgCard[]>([]);
const isLoading = ref<boolean>(false);
const error = ref<string | null>(null);

let activeController: AbortController | null = null;
let requestId = 0;

export function useScryfallAPI() {
  const searchCards = async (filters?: CardFilters) => {
    // Cancel any previous search
    activeController?.abort();
    activeController = new AbortController();

    const controller = activeController;
    const currentRequest = ++requestId;

    isLoading.value = true;
    error.value = null;

    const isCurrentRequest = () => currentRequest === requestId;

    try {
      const queryParts: string[] = ['game:paper'];

      const searchTerm = filters?.query?.trim();

      if (searchTerm) {
        // Search card names first
        const escapedName = searchTerm
          .replace(/\\/g, '\\\\')
          .replace(/"/g, '\\"');

        queryParts.push(`name:"${escapedName}"`);
      }

      if (filters?.color) {
        const colorMap: Record<string, string> = {
          White: 'c:w',
          Blue: 'c:u',
          Black: 'c:b',
          Red: 'c:r',
          Green: 'c:g',
          Colorless: 'c:c',
          Multicolor: 'c:m'
        };

        const colorQuery = colorMap[filters.color];

        if (colorQuery) {
          queryParts.push(colorQuery);
        }
      }

      if (filters?.type) {
        queryParts.push(`t:${filters.type.toLowerCase()}`);
      }

      if (
        filters?.maxCost !== null &&
        filters?.maxCost !== undefined
      ) {
        queryParts.push(`cmc<=${filters.maxCost}`);
      }

      const buildUrl = (query: string) =>
        `https://api.scryfall.com/cards/search?q=${encodeURIComponent(query)}&order=name`;

      let response = await fetch(
        buildUrl(queryParts.join(' ')),
        { signal: controller.signal }
      );

      // If the name search returns no cards, try a broader search.
      if (response.status === 404 && searchTerm) {
        const fallbackParts = [
          'game:paper',
          `"${searchTerm.replace(/"/g, '\\"')}"`
        ];

        if (filters?.color) {
          const colorMap: Record<string, string> = {
            White: 'c:w',
            Blue: 'c:u',
            Black: 'c:b',
            Red: 'c:r',
            Green: 'c:g',
            Colorless: 'c:c',
            Multicolor: 'c:m'
          };

          if (colorMap[filters.color]) {
            fallbackParts.push(colorMap[filters.color]);
          }
        }

        if (filters?.type) {
          fallbackParts.push(`t:${filters.type.toLowerCase()}`);
        }

        if (
          filters?.maxCost !== null &&
          filters?.maxCost !== undefined
        ) {
          fallbackParts.push(`cmc<=${filters.maxCost}`);
        }

        response = await fetch(
          buildUrl(fallbackParts.join(' ')),
          { signal: controller.signal }
        );
      }

      if (!isCurrentRequest()) return;

      if (response.status === 404) {
        cards.value = [];
        return;
      }

      if (!response.ok) {
        throw new Error(`Scryfall API error (${response.status})`);
      }

      const data = await response.json();

      if (!isCurrentRequest()) return;

      if (data.object === 'list' && Array.isArray(data.data)) {
        cards.value = data.data.map((card: any): MtgCard => ({
          id: card.id,
          name: card.name,
          type: card.type_line || 'Unknown',
          color: parseColor(card.colors),
          cost: Number(card.cmc ?? 0),
          tags: card.keywords || [],
          image:
            card.image_uris?.normal ||
            card.card_faces?.[0]?.image_uris?.normal ||
            ''
        })).filter((card: MtgCard) => card.image !== '');
      } else {
        cards.value = [];
      }

    } catch (err: unknown) {
      if (
        err instanceof Error &&
        err.name === 'AbortError'
      ) {
        return;
      }

      if (isCurrentRequest()) {
        error.value =
          err instanceof Error
            ? err.message
            : 'Failed to load cards from Scryfall.';

        cards.value = [];
        console.error('Scryfall search failed:', err);
      }

    } finally {
      if (isCurrentRequest()) {
        isLoading.value = false;
      }
    }
  };

  return {
    cards,
    isLoading,
    error,
    searchCards
  };
}

function parseColor(colors: string[] | undefined): string {
  if (!colors || colors.length === 0) {
    return 'Colorless';
  }

  if (colors.length > 1) {
    return 'Multicolor';
  }

  const colorMap: Record<string, string> = {
    W: 'White',
    U: 'Blue',
    B: 'Black',
    R: 'Red',
    G: 'Green'
  };

  return colorMap[colors[0]] || 'Colorless';
}
